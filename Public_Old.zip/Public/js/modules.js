/**
 * Created by zhy on 16/6/10.
 */
var ADD_CONTRACT_EXIST = false;
var DELETE_CONTRACT_EXIST = false;
// var GO_LAST_PAGE_EXIST = false;
// var GO_NEXT_PAGE_EXSIT = false;


$.addContractModule = function () {
    ul.html(ul.html() + '<li class="add-contract">' +
        '<h5>添加合同</h5>' +
        '<form action="../../" method="post" enctype="multipart/form-data">' +
        '<input type="file" name="file">' +
        '<input type="text" name="action" value="upload">' +
        '<input type="submit" class="function" value="提交">' +
        '</form>' +
        '</li>');
    
    ADD_CONTRACT_EXIST = true;
};

$.removeAddContractModule = function () {
    $("li.add-contract").remove();
    ADD_CONTRACT_EXIST = false;
};

$.deleteContractModule = function () {
    ul.html(ul.html() + '<li class="delete-contract">' +
        '<h5>删除合同</h5>' +
        '<input type="button" class="function" value="删除" onclick="$.deleteContract()">' +
        '</li>');
    
    DELETE_CONTRACT_EXIST = true;
};

$.removeDeleteContractModule = function () {
    $("li.delete-contract").remove();
    DELETE_CONTRACT_EXIST = false;
};

$.changePageModule = function () {
    ul.html(ul.html() + '<li class="change-page">' +
        '<h5>翻页</h5>' +
        '<input type="button" class="function changepage" value="上一页" onclick="$.lastPage()">' +
        '<input type="button" class="function changepage" value="下一页" onclick="$.nextPage()">' +
        '</li>');
    
    // GO_LAST_PAGE_EXIST = true;
    // GO_NEXT_PAGE_EXSIT = true;
};

$.removeChangePageModule = function () {
    $("li.change-page").remove();
    // GO_LAST_PAGE_EXIST = false;
    // GO_NEXT_PAGE_EXSIT = false;
};

$.removeGoLastPageModule = function () {
    $("li.change-page input[value=上一页]").remove();
    // GO_LAST_PAGE_EXIST = false;
};

$.removeGoNextPageModule = function () {
    $("li.change-page input[value=下一页]").remove();
    // GO_NEXT_PAGE_EXSIT = false;
};

$.deleteContract = function () {
    $.post(URL, {
        "action": "delete",
        "contract_id": $("tr.active").find("td")[0].innerHTML
    }, function (data) {
        alert(data);

        //刷新数据
        location.reload(true);
    })
};

$.lastPage = function () {
    presentPageNum--;
    $.changePageNumber();
};

$.nextPage = function () {
    presentPageNum++;
    $.changePageNumber();
};
