/**
 * Created by zhy on 16/6/10.
 */
var table;
var page;
var ul;
var numInOnePage = 12;

$(function () {
    ul = $("ul.operation");
    table = $("div.submain.left table");
    page = $("p.pages");

    //生成table内容
    $.geneTable();

    //添加模块
    $.addContractModule();
    $.deleteContractModule();
    $.changePageModule();
    
    //判断模块
    $.judgeFunctionModules();

    //获取并添加数据
    $.getAndShowDataInTable();
});

// $(window).resize($.setFrameAccordingWindow());


$.judgeFunctionModules = function (clickedTr) {
    //判断删除功能
    if (clickedTr !== undefined) {
        var tds = clickedTr.children("td");
        if ($(tds[0]).html() == "") {
            if (DELETE_CONTRACT_EXIST == true) {
                $("li.delete-contract").remove();
                DELETE_CONTRACT_EXIST = false;
            }
        }
        else {
            if (DELETE_CONTRACT_EXIST == false) {
                $.deleteContractModule();
            }
        }
    }
    
    //判断翻页功能
    $.removeChangePageModule();

    if (presentPageNum == 1 && presentPageNum !== Math.ceil(count / numInOnePage)) {
        $.changePageModule();
        $.removeGoLastPageModule();
    }
    else if (presentPageNum !== 1 && presentPageNum == Math.ceil(count / numInOnePage)) {
        $.changePageModule();
        $.removeGoNextPageModule();
    }
    else {
        $.changePageModule();
    }
};

$.isEditing = function () {
    
};

$.noLastPage = function () {
    
};

$.noNextPage = function () {
    
};

$.justOnePage = function () {
    $.noLastPage();
    $.noNextPage();
};

$.geneTable = function () {
    table.html('<tr class="first-line"><th>序号</th><th>文件名</th><th>提交日期</th><th>下载文件</th></tr><tr class="active"><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td></tr>');
    
    //table各行等高
    var tableHeight = table.height();
    table.find("tr").height(tableHeight / (numInOnePage + 1));

    //table点击事件
    var responsibleTrArr = table.find("tr").not("tr.first-line");

    responsibleTrArr.click(function () {
        $("tr.active").removeClass('active');
        $(this).addClass('active');

        //判断右侧功能模块内容
        $.judgeFunctionModules($(this));
    });
};