/**
 * Created by zhy on 16/6/10.
 */
var contracts = [];//分割完成的合同列表
var count;//总合同数
var keys = ['id', 'name', 'date', 'path'];//解析用键值
var URL = '../../';
var user_id = $("div#user_id").html();
var presentPageNum = 1;


$.getAndShowDataInTable = function () {
    $.getData(function () {
        $.showDataInTable(contracts[0]);

        //第一页
        presentPageNum = 1;
        
        //设置页码
        $.changePageNumber();
    })
};

$.getData = function (callBack) {
    $.post(URL, {
        'action': 'all_contracts',
        'user_id': user_id
    }, function (data, status) {
        count = data.length;
        $.divideData(data);

        callBack();
    });
};

$.divideData = function (undivided_contracts) {
    var tempArr = [];

    $(undivided_contracts).each(function (index) {
        var contractDic = this;

        if (index % numInOnePage == 0 && index != 0) {
            //满十个推入列表
            contracts.push(tempArr);
            tempArr = [];
        }

        //拼接合同(字典转数组)
        var contract = [];

        keys.forEach(function (key) {
            contract.push(contractDic[key]);
        });

        tempArr.push(contract);
    });

    //如果有剩余
    if (tempArr.length != 0) {
        contracts.push(tempArr);
    }
};

$.showDataInTable = function (dataSource) {
    var trArr = table.find("tr").not("tr.first-line");
    var tdArr = [];

    $(trArr).each(function () {
        tdArr.push($(this).find("td"));
    });

    $(dataSource).each(function (trIndex) {
        var dataRow = this;

        $(tdArr[trIndex]).each(function (tdIndex) {
            //最后一行
            if (tdIndex == tdArr[trIndex].length - 1) {
                $(this).html('<a href="' + dataRow[tdIndex] + '">下载</a>');
                return;
            }

            $(this).html(dataRow[tdIndex]);
        });
    })
};

$.changePageNumber = function () {
    page.html(presentPageNum + '/' + Math.ceil(count / numInOnePage));
    
    //判断右侧功能模块
    $.judgeFunctionModules();
    
    //清空table
    table.empty();

    //重新生成table
    $.geneTable();

    //填充table内容
    $.showDataInTable(contracts[presentPageNum - 1]);
};

$.jumpToPage = function (num) {
    presentPageNum = num;
    $.showDataInTable(contracts[presentPageNum - 1]);
    $.changePageNumber();
};

